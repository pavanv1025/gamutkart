package com.gamutkart;

public class App 
{
    public static void main( String[] args )
    {
		int i;

		for(i=0;i<=3;i++)
		{
			i += 5;
   		}
	 }
}
